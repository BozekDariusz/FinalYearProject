

#include "Header.h"


using namespace std;
const vector<string> explode(const string& s, const char& c)
{
    string buff{ "" };
    vector<string> v;

    for (auto n : s)
    {
        if (n != c) buff += n; else
            if (n == c && buff != "") { v.push_back(buff); buff = ""; }
    }
    if (buff != "") v.push_back(buff);

    return v;
}
void loadFile() {
    {//load file
        ifstream faceFile;
        string fileName = "C:/Users/Dracops/source/repos/distanceFields/distanceFields/"+name+".db";
        faceFile.open(fileName);


        vector<string> v;
        std::string line;
        int i = -1;
        if (faceFile.is_open())
        {
            getline(faceFile, line);
            allX = stoi(line);
            getline(faceFile, line);
            allY = stoi(line);
            getline(faceFile, line);
            allZ = stoi(line);
            while (getline(faceFile, line)) {
                if (!line.empty()) {
                    v = explode(line, ' ');
                }
                else {
                    v[0] = "empty";
                }
                if (v[0] == "#") continue;
                if (stof(v[0]) <= 0.5) {
                    distanceMap.push_back(0);

                }
                else {
                    distanceMap.push_back(1);
                }


            }

        }
    }
}//load file


int main()
{
    chrono::steady_clock sc;   // create an object of `steady_clock` class
    auto start = sc.now();     // start timer
    name = "sphere2";
    loadFile();
    std::vector<int> index = { 0, 0, 0, 0, 0, 0, 0, 0 }; 
    std::vector<tVector3> vertices;
    std::vector<tVector3> faceVertices;
    int iFlagIndex;
    int iEdgeFlags;
    for (int i = 0; i <= allX - 2; i++) {
        for (int j = 0; j <= allY - 2; j++) {
            for (int k = 0; k <= allZ - 2; k++) {
                index[0] = distanceMap[i * allZ * allY + j * allZ + k];
                index[1] = distanceMap[(i + 1) * allZ * allY + j * allZ + k];
                index[2] = distanceMap[(i + 1) * allZ * allY + j * allZ + k + 1];
                index[3] = distanceMap[i * allZ * allY + j * allZ + k + 1];
                index[4] = distanceMap[i * allZ * allY + (j + 1) * allZ + k];
                index[5] = distanceMap[(i + 1) * allZ * allY + (j + 1) * allZ + k];
                index[6] = distanceMap[(i + 1) * allZ * allY + (j + 1) * allZ + k + 1];
                index[7] = distanceMap[i * allZ * allY + (j + 1) * allZ + k + 1];
                

                //Find which vertices are inside of the surface and which are outside
                iFlagIndex = 0;
                for (int iVertexTest = 0; iVertexTest < 8; iVertexTest++)
                {
                    if (index[iVertexTest] == 1)
                        iFlagIndex = iFlagIndex + (pow(2.0, iVertexTest));

                }

           


                vertices.clear();
                for (int iEdge = 0; iEdge < 12; iEdge++)//interpolation to create vertices 
                {

                    tVector3 X((2.0*(i )+verticesCords[edgeVertices[iEdge][0]][0] + verticesCords[edgeVertices[iEdge][1]][0]) / 2.0,
                        (2.0 * ( k )+verticesCords[edgeVertices[iEdge][0]][1] + verticesCords[edgeVertices[iEdge][1]][1]) / 2.0,
                        (2.0 * ( j)+verticesCords[edgeVertices[iEdge][0]][2] + verticesCords[edgeVertices[iEdge][1]][2]) / 2.0);


                    vertices.push_back(X);

                }

                for (int iTriangle = 0; iTriangle < 5; iTriangle++)//create faces from vertices
                {

                    faceVertices.clear();
                    if (traingles[iFlagIndex][3 * iTriangle] < 0)
                        break;

                    for (int iCorner = 0; iCorner < 3; iCorner++)
                    {

                        int iVertex = traingles[iFlagIndex][3 * iTriangle + iCorner];


                        faceVertices.push_back(vertices[iVertex]);
                    }
                    mesh.faces.push_back(face(faceVertices[0], faceVertices[1], faceVertices[2]));
                }
        
            }
        }
    }
    
    auto end = sc.now();       // end timer (starting & ending is done by measuring the time at the moment the process started & ended respectively)
    auto time_span = static_cast<chrono::duration<double>>(end - start);



    string fileName = name + "Marched.obj";
    ofstream faceFile;
    faceFile.open(fileName);



    for (int iFace = 0; iFace < mesh.faces.size(); iFace++) {

        faceFile << "v " << mesh.faces[iFace].A.x << " " << mesh.faces[iFace].A.y << " " << mesh.faces[iFace].A.z << "\n";
        faceFile << "v " << mesh.faces[iFace].B.x << " " << mesh.faces[iFace].B.y << " " << mesh.faces[iFace].B.z << "\n";
        faceFile << "v " << mesh.faces[iFace].C.x << " " << mesh.faces[iFace].C.y << " " << mesh.faces[iFace].C.z << "\n";
    }
    for (int iFace = 0; iFace < mesh.faces.size(); iFace++) {

        faceFile << "f "<<iFace*3+1<< " "<<iFace * 3 + 2 << " "<<iFace * 3 + 3 << "\n";
    }
    faceFile << "# " << time_span.count() <<"\n";

    faceFile.close();
    int eadfeadvf = 0;
}

