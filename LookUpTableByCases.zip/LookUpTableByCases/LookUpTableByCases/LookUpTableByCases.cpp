
#include "Header.h"

int main()
{
	std::vector<int> tempCube{
		0, 1, 2, 3, 4, 5, 6, 7
	};
	std::vector<std::vector<int>> traingles;
	int tempCaseNumber = 0;

	std::vector<int> tempCase{ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
	std::vector<int > tempEdge{ 0,1,2,3,4,5,6,7,8,9,10,11 };
	std::vector<int > cubeInside{ 0,0,0,0,0,0,0,0 };
	std::vector<int > tempCubeInside{ 0,0,0,0,0,0,0,0 };
	std::vector<int > tempCubeState{ 0,0,0,0,0,0,0,0 };
	std::vector<int > tempCubeInside2{ 0,0,0,0,0,0,0,0 };
	for (int iRBits = 0; iRBits < 16; iRBits++) {
		for (int iDBits = 0; iDBits < 16; iDBits++) {
			tempCubeState = cube;
	
			
			tempCubeInside = cubeInside;

			for (int iX = 0; iX < 8; iX++) {
				for (int iY = 0; iY < 3; iY++) {



				//case0
				if(cubeInside[0] == 0 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 0 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 0 

					){

					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					traingles.push_back(tempCase);

						cube[0]=tempCubeState[0];
						cube[1]=tempCubeState[1];
						cube[2]=tempCubeState[2];
						cube[3]=tempCubeState[3];
						cube[4]=tempCubeState[4];
						cube[5]=tempCubeState[5];
						cube[6]=tempCubeState[6];
						cube[7]=tempCubeState[7];
						iX = 9;
						break;
				}

				//case1
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 0 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 0

					) {
					std::vector<int>temp;

					temp.push_back(edge[0]);
					temp.push_back(edge[3]);
					temp.push_back(edge[8]);

					std::sort(temp.begin(), temp.end());
					tempCase[0] = temp[0];
					tempCase[1] = temp[1];
					tempCase[2] = temp[2];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];

					iX = 9;
					break;
				}


				//case2
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 0 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 0

					) {
					std::vector<int>temp;
					/*
					temp.push_back(edge[1]);
					temp.push_back(edge[3]);
					temp.push_back(edge[8]);
					temp.push_back(edge[9]);

					std::sort(temp.begin(), temp.end());

					
					tempCase[0] = temp[0];
					tempCase[1] = temp[1];
					tempCase[2] = temp[2];
					tempCase[3] = temp[0];
					tempCase[4] = temp[1];
					tempCase[5] = temp[3];

					*/
						

					tempCase[0] = edge[9];
					tempCase[1] = edge[3];
					tempCase[2] = edge[8];

					tempCase[3] = edge[1];
					tempCase[4] = edge[3];
					tempCase[5] = edge[9];
					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case3
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 0 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 0

					) {



					tempCase[0] = edge[0];
					tempCase[1] = edge[3];
					tempCase[2] = edge[8];

					tempCase[3] = edge[1];
					tempCase[4] = edge[2];
					tempCase[5] = edge[10];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case4
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 0 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 0

					) {

					tempCase[0] = edge[0];
					tempCase[1] = edge[3];
					tempCase[2] = edge[8];

					tempCase[3] = edge[5];
					tempCase[4] = edge[6];
					tempCase[5] = edge[10];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case5
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 0

					) {

					tempCase[0] = edge[8];
					tempCase[1] = edge[0];
					tempCase[2] = edge[1];

					tempCase[3] = edge[8];
					tempCase[4] = edge[1];
					tempCase[5] = edge[7];
					
					tempCase[6] = edge[7];
					tempCase[7] = edge[1];
					tempCase[8] = edge[5];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case6
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 0 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 0

					) {
					std::vector<int>temp;

			

					tempCase[0] = edge[3];
					tempCase[1] = edge[8];
					tempCase[2] = edge[9];

					tempCase[3] = edge[1];
					tempCase[4] = edge[3];
					tempCase[5] = edge[9];

					tempCase[6] = edge[5];
					tempCase[7] = edge[6];
					tempCase[8] = edge[10];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case7
				if ( cubeInside[0] == 0 &&
					 cubeInside[1] == 1 &&
					 cubeInside[2] == 0 &&
					 cubeInside[3] == 1 &&
					 cubeInside[4] == 0 &&
					 cubeInside[5] == 0 &&
					 cubeInside[6] == 1 &&
					 cubeInside[7] == 0

					) {

					tempCase[0] = edge[2];
					tempCase[1] = edge[3];
					tempCase[2] = edge[11];

					tempCase[3] = edge[0];
					tempCase[4] = edge[1];
					tempCase[5] = edge[9];

					tempCase[6] = edge[5];
					tempCase[7] = edge[6];
					tempCase[8] = edge[10];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case8
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 0

					) {
					std::vector<int>temp;



					tempCase[0] = edge[3];
					tempCase[1] = edge[7];
					tempCase[2] = edge[5];

					tempCase[3] = edge[3];
					tempCase[4] = edge[1];
					tempCase[5] = edge[5];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case9
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 1

					) {

					tempCase[0] = edge[0];
					tempCase[1] = edge[3];
					tempCase[2] = edge[11];

					tempCase[3] = edge[0];
					tempCase[4] = edge[6];
					tempCase[5] = edge[11];

					tempCase[6] = edge[0];
					tempCase[7] = edge[6];
					tempCase[8] = edge[9];

					tempCase[9] = edge[5];
					tempCase[10] = edge[6];
					tempCase[11] = edge[9];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case10
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 0

					) {
			

					tempCase[0] = edge[0];
					tempCase[1] = edge[8];
					tempCase[2] = edge[11];

					tempCase[3] = edge[0];
					tempCase[4] = edge[2];
					tempCase[5] = edge[11];

					tempCase[6] = edge[4];
					tempCase[7] = edge[9];
					tempCase[8] = edge[10];

					tempCase[9] = edge[4];
					tempCase[10] = edge[6];
					tempCase[11] = edge[10];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case11
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 0

					) {

					
					tempCase[0] = edge[0];
					tempCase[1] = edge[3];
					tempCase[2] = edge[7];

					tempCase[3] = edge[0];
					tempCase[4] = edge[7];
					tempCase[5] = edge[10];

					tempCase[6] = edge[6];
					tempCase[7] = edge[7];
					tempCase[8] = edge[10];


					tempCase[9] =  edge[0];
					tempCase[10] = edge[9];
					tempCase[11] = edge[10];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case12
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 0

					) {

					tempCase[0] = edge[3];
					tempCase[1] = edge[11];
					tempCase[2] = edge[2];

					tempCase[3] = edge[0];
					tempCase[4] = edge[1];
					tempCase[5] = edge[8];

					tempCase[6] = edge[8];
					tempCase[7] = edge[1];
					tempCase[8] = edge[7];

					tempCase[9] = edge[7];
					tempCase[10] = edge[1];
					tempCase[11] = edge[5];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case13
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 1

					) {

					tempCase[0] = edge[0];
					tempCase[1] = edge[8];
					tempCase[2] = edge[3];

					tempCase[3] = edge[11];
					tempCase[4] = edge[6];
					tempCase[5] = edge[7];

					tempCase[6] = edge[1];
					tempCase[7] = edge[2];
					tempCase[8] = edge[10];

					tempCase[9] = edge[9];
					tempCase[10] = edge[4];
					tempCase[11] = edge[5];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };

					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case14
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 1

					) {
			

					tempCase[0] = edge[0];
					tempCase[1] = edge[8];
					tempCase[2] = edge[11];

					tempCase[3] = edge[0];
					tempCase[4] = edge[11];
					tempCase[5] = edge[5];

					tempCase[6] = edge[0];
					tempCase[7] = edge[5];
					tempCase[8] = edge[1];

					tempCase[9] = edge[5];
					tempCase[10] = edge[11];
					tempCase[11] = edge[6];

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case15
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 0 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 1

					) {

					tempCase[0] = edge[0];
					tempCase[1] = edge[3];
					tempCase[2] = edge[11];

					tempCase[3] = edge[0];
					tempCase[4] = edge[6];
					tempCase[5] = edge[11];

					tempCase[6] = edge[0];
					tempCase[7] = edge[6];
					tempCase[8] = edge[9];

					tempCase[9] = edge[5];
					tempCase[10] = edge[6];
					tempCase[11] = edge[9];

					tempCase[12] = edge[2];
					tempCase[13] = edge[1];
					tempCase[14] = edge[10];

					tempCase[15] = -2;

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case16
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 1

					) {

					tempCase[0] = edge[8];
					tempCase[1] = edge[9];
					tempCase[2] = edge[5];

					tempCase[3] = edge[5];
					tempCase[4] = edge[8];
					tempCase[5] = edge[6];

					tempCase[6] = edge[6];
					tempCase[7] = edge[3];
					tempCase[8] = edge[8];

					tempCase[9] = edge[3];
					tempCase[10] = edge[6];
					tempCase[11] = edge[10];

					tempCase[12] = edge[10];
					tempCase[13] = edge[1];
					tempCase[14] = edge[3];

					tempCase[15] = -2;

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case17
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 0 &&
					cubeInside[5] == 0 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 1

					) {

					tempCase[0] = edge[0];
					tempCase[1] = edge[8];
					tempCase[2] = edge[1];

					tempCase[3] = edge[8];
					tempCase[4] = edge[1];
					tempCase[5] = edge[7];

					tempCase[6] = edge[7];
					tempCase[7] = edge[1];
					tempCase[8] = edge[5];
					tempCase[15] = -2;

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case18
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 0 &&
					cubeInside[7] == 1

					) {

					tempCase[0] = edge[0];
					tempCase[1] = edge[3];
					tempCase[2] = edge[8];

					tempCase[3] = edge[5];
					tempCase[4] = edge[6];
					tempCase[5] = edge[10];
					tempCase[15] = -2;

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case19
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 0 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 1

					) {


				

					tempCase[0] = edge[3];
					tempCase[1] = edge[8];
					tempCase[2] = edge[2];

					tempCase[3] = edge[0];
					tempCase[4] = edge[8];
					tempCase[5] = edge[1];

					tempCase[6] = edge[8];
					tempCase[7] = edge[1];
					tempCase[8] = edge[10];

					tempCase[9] = edge[2];
					tempCase[10] = edge[8];
					tempCase[11] = edge[10];

					tempCase[15] = -2;

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}


				//case20
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 0 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 1

					) {



					tempCase[0] = edge[1];
					tempCase[1] = edge[3];
					tempCase[2] = edge[8];

					tempCase[3] = edge[1];
					tempCase[4] = edge[8];
					tempCase[5] = edge[9];
					tempCase[15] = -2;

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}
				//case21
				if (cubeInside[0] == 0 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 1

					) {

					tempCase[0] = edge[0];
					tempCase[1] = edge[3];
					tempCase[2] = edge[8];
					tempCase[15] = -2;

					traingles.push_back(tempCase);
					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}

				//case22
				if (cubeInside[0] == 1 &&
					cubeInside[1] == 1 &&
					cubeInside[2] == 1 &&
					cubeInside[3] == 1 &&
					cubeInside[4] == 1 &&
					cubeInside[5] == 1 &&
					cubeInside[6] == 1 &&
					cubeInside[7] == 1

					) {


					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -2 };
					traingles.push_back(tempCase);

					tempCase = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
					cube[0] = tempCubeState[0];
					cube[1] = tempCubeState[1];
					cube[2] = tempCubeState[2];
					cube[3] = tempCubeState[3];
					cube[4] = tempCubeState[4];
					cube[5] = tempCubeState[5];
					cube[6] = tempCubeState[6];
					cube[7] = tempCubeState[7];
					iX = 9;
					break;
				}



				tempCubeInside2 = cubeInside;

				cubeInside[0] =tempCubeInside2[0];
				cubeInside[1] =tempCubeInside2[4];
				cubeInside[2] =tempCubeInside2[5];
				cubeInside[3] =tempCubeInside2[1];
				cubeInside[4] =tempCubeInside2[3];
				cubeInside[5] =tempCubeInside2[7];
				cubeInside[6] =tempCubeInside2[6];
				cubeInside[7] =tempCubeInside2[2];

		

				tempCube = cube;
				cube[0] = tempCube[0];
				cube[1] = tempCube[4];
				cube[2] = tempCube[5];
				cube[3] = tempCube[1];
				cube[4] = tempCube[3];
				cube[5] = tempCube[7];
				cube[6] = tempCube[6];
				cube[7] = tempCube[2];
				tempEdge = edge;
				edge[0] = tempEdge[8];
				edge[1] = tempEdge[4];
				edge[2] = tempEdge[9];
				edge[3] = tempEdge[0];
				edge[4] = tempEdge[11];
				edge[5] = tempEdge[6];
				edge[6] = tempEdge[10];
				edge[7] = tempEdge[2];
				edge[8] = tempEdge[3];
				edge[9] = tempEdge[7];
				edge[10] = tempEdge[5];
				edge[11] = tempEdge[1];

			}
			if (iX == 9)break;
			if (iX == 3) {

				tempCubeInside2 = cubeInside;
				cubeInside[0] = tempCubeInside2[5];
				cubeInside[1] = tempCubeInside2[6];
				cubeInside[2] = tempCubeInside2[7];
				cubeInside[3] = tempCubeInside2[4];
				cubeInside[4] = tempCubeInside2[1];
				cubeInside[5] = tempCubeInside2[2];
				cubeInside[6] = tempCubeInside2[3];
				cubeInside[7] = tempCubeInside2[0];

				tempCube = cube;
				cube[0] = tempCube[5];
				cube[1] = tempCube[6];
				cube[2] = tempCube[7];
				cube[3] = tempCube[4];
				cube[4] = tempCube[1];
				cube[5] = tempCube[2];
				cube[6] = tempCube[3];
				cube[7] = tempCube[0];


				tempEdge = edge;//check
				edge[0] = tempEdge[5];
				edge[1] = tempEdge[6];
				edge[2] = tempEdge[7];
				edge[3] = tempEdge[4];
				edge[4] = tempEdge[1];
				edge[5] = tempEdge[2];
				edge[6] = tempEdge[3];
				edge[7] = tempEdge[0];
				edge[8] = tempEdge[9];
				edge[9] = tempEdge[10];
				edge[10] = tempEdge[11];
				edge[11] = tempEdge[8];
			}

			else {


				tempCubeInside2 = cubeInside;

				cubeInside[0] = tempCubeInside2[1];
				cubeInside[1] = tempCubeInside2[2];
				cubeInside[2] = tempCubeInside2[3];
				cubeInside[3] = tempCubeInside2[0];
				cubeInside[4] = tempCubeInside2[5];
				cubeInside[5] = tempCubeInside2[6];
				cubeInside[6] = tempCubeInside2[7];
				cubeInside[7] = tempCubeInside2[4];


				tempCube = cube;
				cube[0] = tempCube[1];
				cube[1] = tempCube[2];
				cube[2] = tempCube[3];
				cube[3] = tempCube[0];
				cube[4] = tempCube[5];
				cube[5] = tempCube[6];
				cube[6] = tempCube[7];
				cube[7] = tempCube[4];


				tempEdge = edge;
				edge[0] = tempEdge[1];
				edge[1] = tempEdge[2];
				edge[2] = tempEdge[3];
				edge[3] = tempEdge[0];
				edge[4] = tempEdge[5];
				edge[5] = tempEdge[6];
				edge[6] = tempEdge[7];
				edge[7] = tempEdge[4];
				edge[8] = tempEdge[9];
				edge[9] = tempEdge[10];
				edge[10] = tempEdge[11];
				edge[11] = tempEdge[8];
			}
			}

			cube={  0,1,2,3,4,5,6,7	};
			edge = { 0,1,2,3,4,5,6,7,8,9,10,11 };

			cubeInside[0] = tempCubeInside[0];
			cubeInside[1] = tempCubeInside[1];
			cubeInside[2] = tempCubeInside[2];
			cubeInside[3] = tempCubeInside[3];
			cubeInside[4] = tempCubeInside[4];
			cubeInside[5] = tempCubeInside[5];
			cubeInside[6] = tempCubeInside[6];
			cubeInside[7] = tempCubeInside[7];


			if (cubeInside[0] == 1) {
				if (cubeInside[1] == 1) {
					if (cubeInside[2] == 1) {

						if (cubeInside[3] == 1) {

						}
						else {
							cubeInside[3] = 1;
							cubeInside[2] = 0;
							cubeInside[1] = 0;
							cubeInside[0] = 0;
						}

					}
					else {
						cubeInside[2] = 1;
						cubeInside[1] = 0;
						cubeInside[0] = 0;
					}
				}
				else {
					cubeInside[1] = 1;
					cubeInside[0] = 0;
				}

			}
			else {
				cubeInside[0] = 1;
			}


		}



		cubeInside[0] = 0;
		cubeInside[1] = 0;
		cubeInside[2] = 0;
		cubeInside[3] = 0;


		if (cubeInside[4] == 1) {
			if (cubeInside[5] == 1) {
				if (cubeInside[6] == 1) {

					if (cubeInside[7] == 1) {

					}
					else {
						cubeInside[7] = 1;
						cubeInside[6] = 0;
						cubeInside[5] = 0;
						cubeInside[4] = 0;
					}

				}
				else {
					cubeInside[6] = 1;
					cubeInside[5] = 0;
					cubeInside[4] = 0;
				}
			}
			else {
				cubeInside[5] = 1;
				cubeInside[4] = 0;
			}

		}
		else {
			cubeInside[4] = 1;
		}

	}
	


	std::ofstream faceFile;
	faceFile.open("test.txt");

	for (int iTriangles = 0; iTriangles < traingles.size(); iTriangles++) {
		faceFile << "{";
		for (int iEdges = 0; iEdges < traingles[iTriangles].size(); iEdges++) {

			faceFile << traingles[iTriangles][iEdges];
			if (iEdges < 15) {
				faceFile << ", ";
			}
		}
		faceFile << "},\n";

	}

	faceFile.close();
	int op = 0;

}

