#pragma once
#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>    

#include <math.h>
#include <vector>

std::vector<int > cube{
       0,1,2,3,4,5,6,7
};
std::vector<int > edge{
       0,1,2,3,4,5,6,7,8,9,10,11
};
std::vector<std::vector<int> > edgeVertices{
{ 0 ,1 }, {1,2}, {2,3}, {3,0},
{4,5}, {5,6},{6,7}, {7,4},
{0,4}, {1,5}, {2,6}, {3,7} };

