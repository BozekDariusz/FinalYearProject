
#include "Header.h"



using namespace std;
const vector<string> explode(const string& s, const char& c)
{
    string buff{ "" };
    vector<string> v;

    for (auto n : s)
    {
        if (n != c) buff += n; else
            if (n == c && buff != "") { v.push_back(buff); buff = ""; }
    }
    if (buff != "") v.push_back(buff);

    return v;
}

/*
float distance1(tVector3 P, tVector3 A, tVector3 B) //callculates distance from a point to a line 
{
    /*
    tVector3 R = cross(cross(B.operator-(P), A.operator-(P)), B.operator-(A));
    float angle = (dot(A.operator-(P), R)) / (((A.operator-(P)).mag) * (R.mag));
    float P0 = (A.operator-(P)).mag * angle;
    tVector3 P0vec = (R.operator/(R.mag)).operator*(P0);
    tVector3 P0pos = (P.operator+(P0vec));
    float t = (P0pos.x - A.x) / (B.x -A.x);

    return t ;

    */
/*
   tVector3 ab = B.operator-(A);
   tVector3 av = P.operator-(A);
   float d1 = dot(av, ab);
    if (d1 <= 0.0)           // Point is lagging behind start of the segment, so perpendicular distance is not viable.
        return av.mag;         // Use distance to start of segment instead.

    tVector3 bv = P.operator-(B);

    float d2 = dot(ab, ab);
    /*
    if (dot(bv,ab) >= 0.0)           // Point is advanced past the end of the segment, so perpendicular distance is not viable.
        return  modulus(bv);         // Use distance to end of the segment instead.

    return (modulus((cross(ab,av))) / modulus(ab));
    *//*
    if (d2<=d1)
        return bv.mag;
    double dd = d1 / d2;
    tVector3 pdd = A.operator+(ab.operator*(dd));
    return (P.operator-(pdd)).mag;
}
float findDistance(tVector3 p, face f) {

    /*
    tVector3 Ap = p.operator-(f.A);
    float angle = (dot(Ap, f.faceNorm)) / (Ap.mag * f.faceNorm.mag);
    float p0Length = ((f.A.operator-(p)).mag) * angle;
    tVector3 p0Vec;
    if (angle > 0) {
        p0Vec = (f.faceNorm.operator/(f.faceNorm.mag)).operator*(-p0Length);
}
    else {
    
         p0Vec = (f.faceNorm.operator/(f.faceNorm.mag)).operator*(p0Length);
    }
    tVector3 p0Pos = p.operator+(p0Vec);
    if (p0Length < 0) 
    {
        p0Length = abs(p0Length);
    }*/
    /*
    tVector3 v1 = f.B.operator-(f.A).operator/(f.B.operator-(f.A).mag).operator+(f.C.operator-(f.A).operator/(f.C.operator-(f.A).mag)) ;
    tVector3 v2 = f.C.operator-(f.B).operator/(f.C.operator-(f.B).mag).operator+(f.A.operator-(f.B).operator/(f.A.operator-(f.B).mag));
    tVector3 v3 = f.A.operator-(f.C).operator/(f.A.operator-(f.C).mag).operator+(f.B.operator-(f.C).operator/(f.B.operator-(f.C).mag));
    float f1=dot(cross(v1,f.A.operator-(p0Pos)),f.faceNorm);
    float f2=dot(cross(v2, f.B.operator-(p0Pos)), f.faceNorm);
    float f3= dot(cross(v3, f.C.operator-(p0Pos)), f.faceNorm);


    */
    /*
    double alpha = distance(p0Pos, f.C, f.B) / distance(f.A, f.B, f.C);
    double beta = distance(p0Pos, f.A, f.C) / distance(f.B, f.A, f.C);
    double gamma = distance(p0Pos, f.A, f.B) / distance(f.C, f.A, f.B);

  


    if (alpha < 0)
    {*/
        /*
        tVector3 r = cross(cross(p0Pos.operator-(f.B),p0Pos.operator-(f.C)),f.C.operator-(f.B));
        float angle1= (dot(p0Pos.operator-(f.C), r)) / ((p0Pos.operator-(f.C)).mag * r.mag);
        float length1 = p0Pos.operator-(f.C).mag * angle1;
        tVector3 p01Vec = r.operator/(r.mag).operator*(length1);
        tVector3 p0P1os = p0Pos.operator+(p01Vec);
        float t=p01Vec.operator-().op
   *//*
        return distance1(p,f.B,f.C);
   }
    if (beta < 0)
    {
        return distance1(p,f.A,f.C);
    }
    if (gamma < 0)
    {
        return distance1(p,f.A,f.B);
    }
   





    return p0Length;
    */
 /*
    tVector3 w = p.operator-(f.A);
    /*
    if (p.x == 1 && p.y == 1 && p.z == 0) {
        int wa = 0;
        
    }
  */  /*  
    float gamma = dot(cross(f.B.operator-(f.A),w),f.faceNorm) / dot(f.faceNorm,f.faceNorm);
   
    float beta = dot(cross(w,f.C.operator-(f.A)), f.faceNorm) / dot(f.faceNorm, f.faceNorm); 
    float alpha = 1 - gamma - beta;

    tVector3 p0 = ((f.A.operator*(alpha)).operator+(f.B.operator*(beta))).operator+(f.C.operator*(gamma));
    if ((0 <= alpha) && (alpha <= 1) &&
        (0 <= beta) && (beta <= 1) &&
        (0 <= gamma) && (gamma <= 1)) {
        return (p.operator-(p0)).mag;

    }
    float BC = distance1(p, f.B, f.C);
    float AC = distance1(p, f.A, f.C);
    float AB = distance1(p, f.A, f.B);
    if (BC <= AC&&BC<=AB)
    {
            return BC;
       }
    if (AC<=BC&&AC<=AB)
        {
            return AC;
        }
    if (AB<=AC&&AB<=BC)
        {
            return AB;
        }






}




*/



float distancePointer(tVector3 *P, tVector3 *A, tVector3 *B) //callculates distance from a point to a line 
{


    tVector3 ab = B->operator-(A);
    tVector3 av = P->operator-(A);
    float d1 = dot(av, ab);
    if (d1 <= 0.0)           
        return av.mag;         

    tVector3 bv = P->operator-(B);

    float d2 = dot(ab, ab);
   
    if (d2 <= d1)
        return bv.mag;
    double dd = d1 / d2;
    tVector3 pdd = A->operator+(ab.operator*(dd));
    return (P->operator-(pdd)).mag;
}

float findDistancePointer(tVector3 *p, face *f) {


    tVector3 w = p->operator-(f->A);

    float gamma = dot(cross(f->B.operator-(f->A), w), f->faceNorm) / dot(f->faceNorm, f->faceNorm);
    float beta = dot(cross(w, f->C.operator-(f->A)), f->faceNorm) / dot(f->faceNorm, f->faceNorm);
    float alpha = 1 - gamma - beta;

   
    if ((0 <= alpha) && (alpha <= 1) &&
        (0 <= beta) && (beta <= 1) &&
        (0 <= gamma) && (gamma <= 1)) {
        tVector3 p0 = ((f->A.operator*(alpha)).operator+(f->B.operator*(beta))).operator+(f->C.operator*(gamma));
        return (p->operator-(p0)).mag;

    }
    float BC = distancePointer(p, &f->B, &f->C);
    float AC = distancePointer(p, &f->A, &f->C);
    float AB = distancePointer(p, &f->A, &f->B);

    if (BC <= AC && BC <= AB)
    {
        return BC;
    }
    if (AC <= BC && AC <= AB)
    {
        return AC;
    }
    if (AB <= AC && AB <= BC)
    {
        return AB;
    }

}






int main(int argc, char** argv)
{
    chrono::steady_clock sc;   // create an object of `steady_clock` class
    auto start = sc.now();     // start timer


    int scale =2;
    string figure = "sphere";
    //load file
    {//load file 
        ifstream faceFile;
        string fileName = figure+".obj";
        faceFile.open(fileName);


        vector<string> v;
        std::string line;
        int i = -1;

        //load file
        if (faceFile.is_open())
        {
            while (getline(faceFile, line)) {
                if (!line.empty()) {
                    v = explode(line, ' ');
                }
                else {
                    v[0] = "empty";
                }
                if (!v[0].compare("g")) {
                    obj temp;
                    temp.name = line;
                    getline(faceFile, line);
                    temp.usemtl = line;
                    objects->push_back(temp);
                    i++;
                }

                if (!v[0].compare("v")) {
                    if (i == -1) {
                        i = 0;
                        obj temp;
                        objects->push_back(temp);

                    }
                    tVector3 tempV{ stof(v[1]),stof(v[2]),stof(v[3]) };
                    objects[0][i].vertices.push_back(tempV);


                }


                if (!v[0].compare("vt")) {
                    tVector3 tempV{ stof(v[1]),stof(v[2]),0 };
                    objects[0][i].verticesTextures.push_back(tempV);

                }
                if (!v[0].compare("vn")) {
                    tVector3 tempV{ stof(v[1]),stof(v[2]),stof(v[3]) };
                    objects[0][i].verticesNormals.push_back(tempV);
                }
                if (!v[0].compare("f")) {
                    vector<string> face1, face2, face3, face4;
                    face1 = explode(v[1], '/');
                    face2 = explode(v[2], '/');
                    face3 = explode(v[3], '/');



                    tVector3 tempFace1{ stof(face1[0]),stof(face2[0]),stof(face3[0]) };
                  //  tVector3 tempFace2{ stof(face1[1]),stof(face2[1]),stof(face3[1]) };
                  //  tVector3 tempFace3{ stof(face1[2]),stof(face2[2]),stof(face3[2]) };

                    face tempFace(objects[0][0].vertices[tempFace1.x-1], objects[0][0].vertices[tempFace1.y-1], objects[0][0].vertices[tempFace1.z-1]);
                    objects[0][i].faces.push_back(tempFace);
                    if (v.size() == 5) {
                        face4 = explode(v[4], '/');

                        tVector3 tempFace1{ stof(face1[0]),stof(face3[0]),stof(face4[0]) };
                     //   tVector3 tempFace2{ stof(face1[1]),stof(face3[1]),stof(face4[1]) };
                       // tVector3 tempFace3{ stof(face1[2]),stof(face3[2]),stof(face4[2]) };

                        face tempFace(objects[0][0].vertices[tempFace1.x-1], objects[0][0].vertices[tempFace1.y-1], objects[0][0].vertices[tempFace1.z-1]);
                        objects[0][i].faces.push_back(tempFace);
                    }
                }
            }
        }
    }

    //create one object from all vertices and faces
    for (int i = 0; i < objects->size(); i++) {
        for (int j = 0; j < objects->at(i).vertices.size(); j++) {
            mesh.vertices.push_back(objects->at(i).vertices[j]);
        }
        for (int j = 0; j < objects->at(i).verticesNormals.size(); j++) {
            mesh.verticesNormals.push_back(objects->at(i).verticesNormals[j]);
        }
        for (int j = 0; j < objects->at(i).verticesTextures.size(); j++) {
            mesh.verticesTextures.push_back(objects->at(i).verticesTextures[j]);
        }
        for (int j = 0; j < objects->at(i).faces.size(); j++) {
            mesh.faces.push_back(objects->at(i).faces[j]);
        }
    }// create mesh

    //create grid
    {

        maxX = mesh.vertices[0].x;
        minX = mesh.vertices[0].x;
        maxY = mesh.vertices[0].y;
        minY = mesh.vertices[0].y;
        maxZ = mesh.vertices[0].z;
        minZ = mesh.vertices[0].z;
        //find max and min of XYZ
        for (int i = 0; i < mesh.vertices.size(); i++) {
            if (maxX < mesh.vertices[i].x) {
                maxX = mesh.vertices[i].x;
            }
            if (minX > mesh.vertices[i].x) {
                minX = mesh.vertices[i].x;
            }
            if (maxY < mesh.vertices[i].y) {
                maxY = mesh.vertices[i].y;
            }
            if (minY > mesh.vertices[i].y) {
                minY = mesh.vertices[i].y;
            }
            if (maxZ < mesh.vertices[i].z) {
                maxZ = mesh.vertices[i].z;
            }
            if (minZ > mesh.vertices[i].z) {
                minZ = mesh.vertices[i].z;
            }



        }

        //create grid 
        for (int i = scale*(minX -2); i <= scale * (maxX +2); i++) {
            for (int j = scale * (minY -2); j <= scale * (maxY +2) ; j ++) {
                for (int k = scale * (minZ -2); k <= scale * (maxZ+2) ; k ++) {
                    vexel temp( float(i)/ scale,  float(j)/ scale, float(k)/ scale);
                    distanceMap.push_back(temp);
                }
            }
        }
    }
  

    int allX = scale * (abs((maxX)-minX) + 4) + 1;
    int allY = scale * (abs((maxY)-minY) + 4) + 1;
    int allZ = scale * (abs((maxZ)-minZ) + 4) + 1;

    //distance calcuation
    for (int i = 0; i < distanceMap.size(); i++) {
         for (int j = 0; j < mesh.faces.size(); j++) {
            float dist = findDistancePointer(&distanceMap[i].pos, &mesh.faces[j]);

            if (distanceMap[i].distance > dist) {
                distanceMap[i].distance = dist;
            }

        }

    }
   


    auto end = sc.now();       // end timer (starting & ending is done by measuring the time at the moment the process started & ended respectively)
    auto time_span = static_cast<chrono::duration<double>>(end - start);   // measure time span between start & end

    
    // output distance field
    {
        string fileName = figure+ std::to_string(scale)+".db";
        ofstream faceFile;
        faceFile.open(fileName);
        faceFile << allX << "\n";
        faceFile << allY<< "\n";
        faceFile << allZ << "\n";

      
        for (int i = 0; i <= allX-1 ; i++) {
            for (int j = 0; j <= allY-1 ; j++) {
                for (int k = 0; k <= allZ-1 ; k++) {
                    faceFile << distanceMap[i * allZ * allY + j * allZ + k].distance<<"\n";
                 
                }
            }
        }

        faceFile << "# "<< time_span.count() << "\n";


        faceFile.close();
    
    }

   
}





