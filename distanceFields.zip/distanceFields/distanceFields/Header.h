#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <math.h>
#include <vector>



typedef struct tVector3					// expanded 3D vector struct
{
    tVector3() {}	// constructor
    tVector3(float new_x, float new_y, float new_z) // initialize constructor
    {
        x = new_x; y = new_y; z = new_z; mag= (x * x) + (y * y) + (z * z);
    }
    void setMag() {
        mag = sqrt((x*x) + (y*y) + (z*z));
    }
    // overload + operator so that we easier can add vectors
    tVector3 operator+(tVector3 vVector) { return tVector3(vVector.x + x, vVector.y + y, vVector.z + z); }
    // overload - operator that we easier can subtract vectors
    tVector3 operator-(tVector3 vVector) { return tVector3(x - vVector.x, y - vVector.y, z - vVector.z); }
    // overload * operator that we easier can multiply by scalars
    tVector3 operator*(float number) { return tVector3(x * number, y * number, z * number); }
    // overload / operator that we easier can divide by a scalar
    tVector3 operator/(float number) { return tVector3(x / number, y / number, z / number); }
 
    tVector3 operator-(tVector3 *vVector) { return tVector3(x - vVector->x, y - vVector->y, z - vVector->z); }


    void norm() {
        x = x / mag;
        y = y / mag;
        z = z / mag;
    }

    float x, y, z,mag;						// 3D vector coordinates

}tVector3;
tVector3 cross(tVector3 a ,tVector3 b) {
    tVector3 temp;
    temp.x = (a.y * b.z) - (a.z * b.y);
    temp.y = (a.z * b.x) - (a.x * b.z);
    temp.z = (a.x * b.y) - (a.y * b.x);
    return temp;

}
float dot(tVector3 a, tVector3 b) {
    return (a.x * b.x )+ (a.y * b.y) + (a.z * b.z);
}

struct face {
    face(tVector3 a,tVector3 b, tVector3 c) {
        A = a;
        B = b;
        C = c;
        faceNorm = cross(b.operator-(a),c.operator-(a));
        faceNorm.setMag();
    }
    tVector3 A;
    tVector3 B;
    tVector3 C;
    tVector3 faceNorm;

};

struct obj {
    std::string name;
    std::string usemtl;
    std::vector<tVector3> vertices;
    std::vector<tVector3> verticesNormals;
    std::vector<tVector3> verticesTextures;
    std::vector<face> faces;

};

obj mesh;

struct vexel{
    vexel(float new_x, float new_y, float new_z) {
        pos.x = new_x;
        pos.y = new_y;
        pos.z = new_z;
    
    }
    tVector3 pos;
    float distance=1000000;
};

std::vector<obj>* objects = new std::vector<obj>;
float maxX = 0;
float minX = 0;
float maxY = 0;
float minY = 0;
float maxZ = 0;
float minZ = 0;
std::vector<vexel> distanceMap;
